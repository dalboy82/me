	   <div class="span-24">
    	<div id="footer">Copyright &copy; <a href="<?php bloginfo('home'); ?>"><strong><?php bloginfo('name'); ?></strong></a>  - <?php bloginfo('description'); ?></div>
        <?php /* 
                    All links in the footer should remain intact. 
                    These links are all family friendly and will not hurt your site in any way. 
                    Warning! Your site may stop working if these links are edited or deleted 
                    
                    You can buy this theme without footer links online at http://newwpthemes.com/buy/?theme=ifitness 
                */ ?>
        <div id="credits">Powered by <a href="http://wordpress.org/"><strong>WordPress</strong></a> | Designed by: <a href="http://backlinksindexer.com/how-to-get-backlinks-indexed">index profile links</a> | Thanks to <a href="http://www.krawikett.de/">www.krawikett.de</a>, <a href="http://www.comptes-bancaires-fr.com/carte-bancaire">carte bancaire</a> and <a href="http://backlinksvault.com">Buy Backlinks</a></div>
        </div>
    </div>
    </div>
</div>

<?php
	 wp_footer();
	echo get_theme_option("footer")  . "\n";
?>

<div style="text-align: center; font-size: 0.75em;"><a target='_blank' href='http://www.freethemes4all.com/wordpress-themes/'>free wordpress themes download</a> | <a target='_blank' href='http://blueseodesign.com'>wordpress tutoriels gratuit</a></div>

</body>
</html>