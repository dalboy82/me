<?php get_header(); ?>
<div class="span-24" id="contentwrap">
	<div class="span-16">
		<div id="content">	
			<h2 class='pagetitle'>Error 404 - Page Not Found</h2>
		</div>
	</div>

<?php get_sidebars(); ?>
	</div>
<?php get_footer(); ?>