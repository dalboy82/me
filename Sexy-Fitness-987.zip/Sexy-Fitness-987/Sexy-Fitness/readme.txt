iFitness theme by NewWpThemes, http://newwpthemes.com
Online Demo: http://newwpthemes.com/demo/iFitness/
Theme URI: http://newwpthemes.com/ifitness-free-wordpress-theme/